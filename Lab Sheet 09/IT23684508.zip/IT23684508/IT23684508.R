setwd("C:\\Users\\Dell\\Desktop\\IT23684508")
data <- rnorm(25, mean = 45, sd = 2)
data

result <- t.test(data, mu = 46, alternative = "less")

result

